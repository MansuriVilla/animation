self.addEventListener('activate', event => {
    event.waitUntil(
      caches.keys().then(cacheNames => {
        return Promise.all(
          cacheNames.map(cacheName => {
            return caches.delete(cacheName);
          })
        );
      })
    );
  });
  




// --- SETUP START ---
const locoScroll = new LocomotiveScroll({
    el: document.querySelector(".smooth-scroll"),
    smooth: true
  });
  // each time Locomotive Scroll updates, tell ScrollTrigger to update too (sync positioning)
  locoScroll.on("scroll", ScrollTrigger.update);
  
  // tell ScrollTrigger to use these proxy methods for the ".smooth-scroll" element since Locomotive Scroll is hijacking things
  ScrollTrigger.scrollerProxy(".smooth-scroll", {
    scrollTop(value) {
      return arguments.length ? locoScroll.scrollTo(value, {duration: 0, disableLerp: true}) : locoScroll.scroll.instance.scroll.y;
    }, // we don't have to define a scrollLeft because we're only scrolling vertically.
    getBoundingClientRect() {
      return {top: 0, left: 0, width: window.innerWidth, height: window.innerHeight};
    },
    // LocomotiveScroll handles things completely differently on mobile devices - it doesn't even transform the container at all! So to get the correct behavior and avoid jitters, we should pin things with position: fixed on mobile. We sense it by checking to see if there's a transform applied to the container (the LocomotiveScroll-controlled element).
    pinType: document.querySelector(".smooth-scroll").style.transform ? "transform" : "fixed"
  });
  
  // each time the window updates, we should refresh ScrollTrigger and then update LocomotiveScroll. 
  ScrollTrigger.addEventListener("refresh", () => locoScroll.update());
  ScrollTrigger.defaults({ scroller: ".smooth-scroll" });
  // --- SETUP END ---








// // Initialize GSAP animations
document.addEventListener('DOMContentLoaded', () => {
    const stickyCards = document.querySelectorAll('.sticky-card');

    let tl = gsap.timeline({
        scrollTrigger: {
            trigger: ".sticky-section",
            pin: true,
            pinSpacing: true,
            markers: false,
            start: "top top",
            end: "+=2000",
            scrub: 1,
        }
    });

    stickyCards.forEach((card, index) => {
        const nextCard = stickyCards[index + 1] || null;

        tl.addLabel(`card${index + 1}`)
          .fromTo(card, {
              yPercent: 75,
              opacity: 0,
          }, {
              yPercent: 0,
              opacity: 1,
          }, `card${index + 1}`)
          .to(card, {
              scale: 0.95,
              yPercent: -0.5,
              opacity: 0.7,
          }, `card${index + 1}+=5.3`);

        if (nextCard) {
            tl.fromTo(nextCard, {
                yPercent: 75,
                opacity: 0,
            }, {
                yPercent: 0,
                opacity: 1,
            }, `card${index + 1}+=5.3`);
        }
    });

    const lastCard = stickyCards[stickyCards.length - 1];
    if (lastCard) {
        tl.to(lastCard, {
            scale: 1,
            yPercent: -0.4,
            opacity: 1,
        });
    }


    // VIDEO SECTION TL START
    gsap.timeline({
        scrollTrigger: {
            trigger: ".video_scale_animation-main",
            start: "top center",
            end: "top top",
            scrub: true,
            markers: false
        }
    })
    .from(".video_scale_animation video", {
        scale: 1.2
    });
    // VIDEO SECTION TL END



    // IMAGE SCALEING SCRITP START
    
        gsap.timeline({
            scrollTrigger: {
                trigger: ".main__aniamtion__img",
                start: "55% 50%",
                end: "120% 50%",
                scrub: 1,
                markers: false  
            }
        })
        .from(".main__aniamtion__img .img__animation", {
            scaleY: 0,
            height:"0%",
            width:"100%",
            duration:"20",
        })
        .to(".main__aniamtion__img .img__animation", {
            scaleY: 5,
            height:"100%",
            width:"100%",
            duration:"20",
        })

    // IMAGE SCALEING SCRITP END
});
